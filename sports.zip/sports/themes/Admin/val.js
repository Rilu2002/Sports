function fname(){
    var f = document.getElementById('fn').value;
    const regf = /^[0-9]+$/;
    if(!regf.test(f)){
        document.getElementById('sfn').innerHTML="only alphabets allowed";
    }
    else{
        document.getElementById('sfn').style.display='None';
    }
}
function mobile(){
    var m = document.getElementById('mb').value;
    const regm = /^[0-9]+$/;
    if(!regm.test(m)){
        document.getElementById('smb').innerHTML="only numbers allowed";
    }
    else{
        document.getElementById('smb').style.display='None';
    }
}
function email(){
    var e = document.getElementById('em').value;
    const rege = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/;
    if(!rege.test(e)){
        document.getElementById('sem').innerHTML="must be entered in correct format";
    }
    else{
        document.getElementById('sem').style.display='None';
    }
}
function password(){
    var p = document.getElementById('ps').value;
    const regp = /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    if(!regp.test(p)){
        document.getElementById('sps').innerHTML='enter the password correctly';
    }
    else{
        document.getElementById('sps').style.display='None';
    }
}
function cpass(){
    var p = document.getElementById('ps').value;
    var cp = document.getElementById('cps').value;
    if(p!=cp){
        document.getElementById('scps').innerHTML="password and confirm password must be same";
    }
    
}
